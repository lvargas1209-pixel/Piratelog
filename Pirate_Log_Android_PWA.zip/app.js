const $=s=>document.querySelector(s);
const KEY="pirate-log-state-v1";
let state=JSON.parse(localStorage.getItem(KEY)||'{"current":207,"seen":[]}');
let selectedArc=null, shown=30;
const statusLabel={watch:"VER",skip:"SALTAR",consider:"CONSIDERAR"};
function save(){localStorage.setItem(KEY,JSON.stringify(state));renderStats();}
function arcFor(ep){return ARCS.find(a=>ep>=a.start&&ep<=a.end)||ARCS[ARCS.length-1];}
function statusFor(arc,ep){const r=arc.ranges.find(x=>ep>=x[0]&&ep<=x[1]);return r?r[2]:"watch";}
function renderStats(){
 const total=ARCS.reduce((n,a)=>n+(a.end-a.start+1),0), seen=state.seen.length;
 $("#currentStat").textContent=state.current;$("#currentArc").textContent=arcFor(state.current).name;
 $("#watchedStat").textContent=seen;const pct=Math.min(100,Math.round(seen/total*100));
 $("#progressStat").textContent=pct+"%";$("#progressBar").style.width=pct+"%";
}
function renderArcs(){
 $("#arcGrid").innerHTML=ARCS.map((a,i)=>`<article class="arc-card" data-arc="${i}"><img src="./assets/${a.image}" alt=""><div class="arc-info"><h3>${a.name}</h3><p>${a.summary}</p><div class="arc-meta"><span>EP. ${a.start}–${a.end}</span><span>ABRIR →</span></div></div></article>`).join("");
 document.querySelectorAll(".arc-card").forEach(el=>el.onclick=()=>openArc(+el.dataset.arc));
}
function openArc(i){selectedArc=i;shown=30;$("#episodesSection").scrollIntoView({behavior:"smooth"});$("#episodeHeading").textContent=ARCS[i].name;renderEpisodes();}
function renderEpisodes(){
 const a=selectedArc===null?null:ARCS[selectedArc];let episodes=[];
 (a?[a]:ARCS).forEach(arc=>{for(let ep=arc.start;ep<=arc.end;ep++){let st=statusFor(arc,ep);episodes.push({ep,arc,st});}});
 const q=$("#search").value.trim().toLowerCase(), f=$("#statusFilter").value;
 episodes=episodes.filter(x=>(!q||String(x.ep).includes(q)||x.arc.name.toLowerCase().includes(q))&&(f==="all"||x.st===f));
 const shownItems=episodes.slice(0,shown);
 $("#episodeList").innerHTML=shownItems.map(x=>`<article class="episode ${x.st}"><img src="./assets/${x.arc.image}" alt="Portada de ${x.arc.name}"><div class="ep-main"><b>Episodio ${x.ep}</b><small>${x.arc.name}</small><span class="tag">${statusLabel[x.st]}</span></div><button class="seen ${state.seen.includes(x.ep)?"done":""}" data-ep="${x.ep}">${state.seen.includes(x.ep)?"VISTO ✓":"Marcar visto"}</button></article>`).join("")||'<p class="muted">No hay episodios que coincidan con tu búsqueda.</p>';
 document.querySelectorAll(".seen").forEach(b=>b.onclick=()=>{let ep=+b.dataset.ep;state.seen=state.seen.includes(ep)?state.seen.filter(x=>x!==ep):[...state.seen,ep];if(state.seen.includes(ep)&&ep>=state.current)state.current=ep+1;save();renderEpisodes();});
 $("#moreBtn").classList.toggle("hidden",episodes.length<=shown);
}
$("#moreBtn").onclick=()=>{shown+=30;renderEpisodes();};
$("#search").oninput=()=>{shown=30;renderEpisodes();};$("#statusFilter").onchange=()=>{shown=30;renderEpisodes();};
$("#backArcs").onclick=()=>{selectedArc=null;$("#episodeHeading").textContent="Todos los episodios";renderEpisodes();};
$("#continueBtn").onclick=()=>{selectedArc=ARCS.findIndex(a=>state.current>=a.start&&state.current<=a.end);openArc(Math.max(0,selectedArc));};
$("#allArcsBtn").onclick=()=>$("#arcsSection").scrollIntoView({behavior:"smooth"});
$("#askBtn").onclick=()=>{let a=arcFor(state.current);let prompt=`Estoy viendo One Piece y voy por el episodio ${state.current} (${a.name}). Responde en español y NO reveles nada posterior a ese episodio. Quiero consultar sobre la serie: `;window.open("https://chatgpt.com/?q="+encodeURIComponent(prompt),"_blank");};
document.querySelectorAll(".bottomnav button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".bottomnav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");if(b.dataset.target==="top")window.scrollTo({top:0,behavior:"smooth"});else document.getElementById(b.dataset.target).scrollIntoView({behavior:"smooth"});});
renderArcs();renderStats();renderEpisodes();
let deferredPrompt;window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("#installBtn").classList.remove("hidden");});
$("#installBtn").onclick=async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("#installBtn").classList.add("hidden");}else alert("En Chrome: menú ⋮ → Añadir a pantalla de inicio o Instalar aplicación.");};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js"));
