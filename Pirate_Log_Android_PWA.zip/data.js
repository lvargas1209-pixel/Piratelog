const ARCS = [
  {
    "name": "Long Ring Long Land",
    "start": 207,
    "end": 226,
    "image": "water7.jpg",
    "summary": "La tripulación participa en los desafíos de Foxy y se abre paso hacia una nueva etapa.",
    "ranges": [
      [
        207,
        219,
        "watch"
      ],
      [
        220,
        226,
        "skip"
      ]
    ]
  },
  {
    "name": "Water 7 & Enies Lobby",
    "start": 227,
    "end": 325,
    "image": "water7.jpg",
    "summary": "Una saga esencial para la tripulación y para la historia del Gobierno Mundial.",
    "ranges": [
      [
        227,
        278,
        "watch"
      ],
      [
        279,
        283,
        "skip"
      ],
      [
        284,
        290,
        "watch"
      ],
      [
        291,
        292,
        "skip"
      ],
      [
        293,
        302,
        "watch"
      ],
      [
        303,
        303,
        "skip"
      ],
      [
        304,
        316,
        "watch"
      ],
      [
        317,
        319,
        "skip"
      ],
      [
        320,
        325,
        "watch"
      ]
    ]
  },
  {
    "name": "Thriller Bark",
    "start": 326,
    "end": 384,
    "image": "thriller.jpg",
    "summary": "Una aventura oscura con nuevos aliados y momentos memorables.",
    "ranges": [
      [
        326,
        336,
        "skip"
      ],
      [
        337,
        381,
        "watch"
      ],
      [
        382,
        384,
        "skip"
      ]
    ]
  },
  {
    "name": "Sabaody, Amazon Lily, Impel Down & Marineford",
    "start": 385,
    "end": 516,
    "image": "marineford.jpg",
    "summary": "Una de las grandes etapas de la serie: mundo, poderes y consecuencias decisivas.",
    "ranges": [
      [
        385,
        405,
        "watch"
      ],
      [
        406,
        407,
        "skip"
      ],
      [
        408,
        417,
        "watch"
      ],
      [
        418,
        420,
        "consider"
      ],
      [
        421,
        425,
        "watch"
      ],
      [
        426,
        429,
        "skip"
      ],
      [
        430,
        452,
        "watch"
      ],
      [
        453,
        456,
        "consider"
      ],
      [
        457,
        458,
        "skip"
      ],
      [
        459,
        491,
        "watch"
      ],
      [
        492,
        492,
        "skip"
      ],
      [
        493,
        516,
        "watch"
      ]
    ]
  },
  {
    "name": "Regreso a Sabaody & Isla Gyojin",
    "start": 517,
    "end": 578,
    "image": "fishman.jpg",
    "summary": "La tripulación vuelve a reunirse y comienza una nueva etapa.",
    "ranges": [
      [
        517,
        541,
        "watch"
      ],
      [
        542,
        542,
        "skip"
      ],
      [
        543,
        574,
        "watch"
      ],
      [
        575,
        578,
        "skip"
      ]
    ]
  },
  {
    "name": "Punk Hazard & Dressrosa",
    "start": 579,
    "end": 746,
    "image": "dressrosa.jpg",
    "summary": "Una saga extensa con alianzas, nuevos personajes y consecuencias para el mundo.",
    "ranges": [
      [
        579,
        625,
        "watch"
      ],
      [
        626,
        627,
        "skip"
      ],
      [
        628,
        746,
        "watch"
      ]
    ]
  },
  {
    "name": "Zou & Whole Cake Island",
    "start": 747,
    "end": 877,
    "image": "wholecake.jpg",
    "summary": "Desarrollo importante de la tripulación, especialmente de Sanji.",
    "ranges": [
      [
        747,
        750,
        "skip"
      ],
      [
        751,
        779,
        "watch"
      ],
      [
        780,
        782,
        "skip"
      ],
      [
        783,
        877,
        "watch"
      ]
    ]
  },
  {
    "name": "Reverie & Wano",
    "start": 878,
    "end": 1085,
    "image": "marineford.jpg",
    "summary": "Grandes acontecimientos mundiales y una saga con una evolución visual notable.",
    "ranges": [
      [
        878,
        906,
        "watch"
      ],
      [
        907,
        907,
        "skip"
      ],
      [
        908,
        1028,
        "watch"
      ],
      [
        1029,
        1030,
        "skip"
      ],
      [
        1031,
        1085,
        "watch"
      ]
    ]
  },
  {
    "name": "Egghead y continuación",
    "start": 1086,
    "end": 1200,
    "image": "dressrosa.jpg",
    "summary": "Etapa más reciente de la historia. Los episodios posteriores pueden actualizarse conforme avance el anime.",
    "ranges": [
      [
        1086,
        1200,
        "watch"
      ]
    ]
  }
];
