const CACHE="pirate-log-v1";
const FILES=["./","./index.html","./style.css","./app.js","./data.js","./manifest.webmanifest","./assets/icon.svg","./assets/water7.jpg","./assets/thriller.jpg","./assets/marineford.jpg","./assets/fishman.jpg","./assets/dressrosa.jpg","./assets/wholecake.jpg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(resp=>{let copy=resp.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return resp;}).catch(()=>caches.match("./index.html"))));});
